export class User {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
    password: string;
    userRole: string;
    status:string;
    createdOn:string
  }